
import os
# os.system('source activate tf1_py2')
# os.system('conda list')

import numpy as np
np.random.seed(13)
import jsonlines
import random

import argparse
parse = argparse.ArgumentParser(description='My Cmd Line Program')

'''
DNA: | 880/15w:41bp, enhancer/enhancer_s:200 bp, 4acC:101

RNA: | ac4c: 415bp, 
=>   | m6A: human1130:41bp, mouse725:41bp, yeast1300:41bp, 
=>   | 4MC: A.thaliana4mC: 41bp, C.elegans4mC:41bp, D.melanogaster4mC, G.subterraneus4mC, G.pickeringii4mC
=>   | m5C: Athaliana_m5C: 41bp, Musculus_m5C:41bp('An improved residual network using deep fusion for
identifying RNA 5-methylcytosine sites')

Protein: | nhKcr/nhKcr_balance:29, IPs_ST/IPs_Y:33bp, Kcr:31bp, Kla:51bp
=>  	 | KaceE.coil / KaceB.subtillis / KaceC.glutamicum 
=>		 | KaceG.kaustophilus / KaceM.tuberculosis / KaceS.typhimurium :21bp
=> iRice_MS: rice_Kac/rice_Kcr/rice_Khib/rice_Kmal/rice_Ksu/rice_Kubi :51bp
'''
parse.add_argument('-species', type=str, default='ac4c', help='880/15w and so on ')
parse.add_argument('-max-len', type=int, default=415, help='the real max length of input sequences')

config = parse.parse_args()


def load_data_bicoding(Path):
    data = np.loadtxt(Path,dtype=list)
    data_result = []

    for seq in data:
        seq = seq.upper()
        seq = str(seq.strip('\n'))
        data_result.append(seq)
    return data_result 


def load_test_bicoding(path_pos_data,path_neg_data):
    
    Positive_X = load_data_bicoding(path_pos_data)
    Negitive_X = load_data_bicoding(path_neg_data)
    
    
    data_test = np.array([[_] + [1] for _ in Positive_X] + [[_] + [0] for _ in Negitive_X])
    
    np.random.seed(42)
    np.random.shuffle(data_test)
    
    X_test = np.array([_[:-1] for _ in data_test])
    y_test = np.array([_[-1] for _ in data_test])
    print(X_test)
    return X_test, y_test


species = config.species
data_path = '/{0}_data/new_data/'.format(species)
train_pos_fa = data_path+'{0}_positive_train_1.fa'.format(species)
train_neg_fa = data_path+'{0}_negative_train_1.fa'.format(species)
test_pos_fa = data_path +'{0}_positive_test_1.fa'.format(species)
test_neg_fa = data_path +'{0}_negative_test_1.fa'.format(species)
#test_neg_fa = data_path +'{0}_negative_test_1.fa'.format(species)
train_all_X, train_all_y = load_test_bicoding(train_pos_fa,train_neg_fa)
test_all_X, test_all_y   = load_test_bicoding(test_pos_fa,test_neg_fa)


print('train_all_X:',train_all_X.shape[0])
print('test_all_X:',test_all_X.shape[0])


#### generate input file for training data
species = config.species # D.melanogaster # A.thaliana
# f1 = open('../{0}_data/{0}_train_Bert.txt'.format(species),'r')
# data1 = f1.readlines()
# f1.close()


embedding_path = 'train_and_test_{}'.format(species)
path = '/BERT_embeding_data/{}/'.format(embedding_path) # use uniprot base

if os.path.exists(path):
    print('OutputDir is exitsted')
else:
    os.makedirs(path)
    print('success create dir test')

'''
    >seq0:1|testing
    AAGAGGGTGTGTTCTGGACCAGTGGCATGAGCAGGTCCAGCTGGGACAACATGGACTATGTGTGGGAGGAGGAGGACGAGGAGGAAGACCTGGACTACTACTTGGGGGACATGGAGGAGGAGGACCTGAGGGGGGAGGATGAGGAGGACGAGGAGGAAGTGCTGGAGGAGGTTGAGGAAGAGGATCTAGACCCCGTCACCCCACTGCCCCCGCCTCCAGCCCCTCGGAGGTGCTTCACATGCCCTCAGTGCCGAAAGAGCTTTCCTCGGCGGAGCTTCCGCCCCAACCTGCAGCTGGCCAATATGGTCCAGGTGATTCGGCAGATGCACCCAACCCCTGGTCGAGGGAGCCGCGTGACCGATCAGGGCATCTGTCCCAAACACCAAGAAGCCCTGAAGCTCTTCTGCGAGGTAGA
'''

Frag=[]
for i in range(len(train_all_X)):
    Frag.append(train_all_X[i][0]+' '+train_all_y[i])

print('print train')
print(Frag[:10])
print('-------------------------->>')
'''
for i in range(len(data1)):
    if i%2==0: #: 0,2,4,,6,
        label=data1[i].strip().split('|')[0].split(':')[1]
        seq=data1[i+1].strip()
        Frag.append(seq+' '+label)
'''


# np.random.shuffle(Frag)
random.shuffle(Frag)
fout1=open(path+'train.tsv','w')        
fout2=open(path+'train-nolabel.tsv','w') 

for line in Frag:
    label=line.split(' ')[1]
    seq = line.split(' ')[0]
    fout1.write(label+'\t') 
    for i in range(len(seq)):
        if i!=(len(seq)-1):
            fout1.write(seq[i]+' ') 
            fout2.write(seq[i]+' ')
        else:
            fout1.write(seq[i]+'\n')
            fout2.write(seq[i]+'\n')


fout1.close()
fout2.close()


### extract features for training data
# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./train_and_test/train-nolabel.tsv --output_file=./train_and_test/train.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16')


os.system('python2 ./extract_features.py --do_lower_case=True --input_file={0}/train-nolabel.tsv --output_file={0}/train.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=512 --batch_size=16'.format(path))



# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./train_and_test/train-nolabel.tsv --output_file=./train_and_test/train.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16')

# model = 'BERT-Mini'
# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./{0}/train-nolabel.tsv --output_file=./{0}/train.jsonl --vocab_file=../BERT-models/{1}/vocab.txt --bert_config_file=../BERT-models/{1}/config.json --init_checkpoint=../BERT-models/{1}/model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16'.format(embedding_path,model))


layer=[]
with jsonlines.open(path+'train.jsonl') as reader: 
    for obj in reader:
        sample=[]
        for j in range(config.max_len): #31
            aa=obj['features'][j]['layers'][0]['values']
            sample.extend(aa)
        layer.append(sample)
print('layer.shape:',np.array(layer).shape)
np.savetxt(path+'train_features.txt',layer,fmt='%s')


#### generate input file for test data
# f2=open('../{0}_data/{0}_test_Bert.txt'.format(species),'r')
# data2=f2.readlines()
# f2.close()


Frag=[]
for i in range(len(test_all_X)):
    Frag.append(test_all_X[i][0]+' '+test_all_y[i])

print('print test')
print(Frag[:10])
print('-------------------------->>')

# Frag=[]
# for i in range(len(data2)):
#     if i%2==0:
#         label=data2[i].strip().split('|')[0].split(':')[1]
#         seq=data2[i+1].strip()
#         Frag.append(seq+' '+label)

# np.random.shuffle(Frag)
random.shuffle(Frag)
fout1=open(path+'test.tsv','w')
fout2=open(path+'test-nolabel.tsv','w')
for line in Frag:
    label=line.split(' ')[1]
    seq=line.split(' ')[0]
    fout1.write(label+'\t')
    for i in range(len(seq)):
        if i!=(len(seq)-1):
            fout1.write(seq[i]+' ')
            fout2.write(seq[i]+' ')
        else:
            fout1.write(seq[i]+'\n')
            fout2.write(seq[i]+'\n')

fout1.close()
fout2.close()

#### extract features for test data
# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./train_and_test/test-nolabel.tsv --output_file=./train_and_test/test.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16')

os.system('python2 ./extract_features.py --do_lower_case=True --input_file={0}/test-nolabel.tsv --output_file={0}/test.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=512 --batch_size=16'.format(path))


# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./train_and_test/test-nolabel.tsv --output_file=./train_and_test/test.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16')

# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./{0}/test-nolabel.tsv --output_file=./{0}/test.jsonl --vocab_file=../BERT-models/{0}/vocab.txt --bert_config_file=../BERT-models/{0}/config.json --init_checkpoint=../BERT-models/{0}/model.ckpt --layers=-1 --max_seq_length=48 --batch_size=16'.format(embedding))

layer=[]
with jsonlines.open(path+'test.jsonl') as reader:
    for obj in reader:
        sample=[]
        for j in range(config.max_len): #31
            aa=obj['features'][j]['layers'][0]['values']
            sample.extend(aa)
        layer.append(sample)
print('layer.shape:',np.array(layer).shape)
np.savetxt(path+'test_features.txt',layer,fmt='%s')







