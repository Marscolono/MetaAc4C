import os
import sys 

file = sys.argv[1]

print('convert fasta file to tsv file for the next step....')
os.system('python2 ./make-input-file.py '+file) # convert fasta file to tsv file for the next step

print('extract features with the pre-trained BERT-Mini model....')
os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./input/test-nolabel.tsv  --output_file=./input/test.jsonl --vocab_file=../BERT-Kcr-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-Kcr-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-Kcr-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16') # extract features with the pre-trained BERT-Mini model

print('convert josnl file to txt file for these extracted features....')
os.system('python2 ./jsonl2txt.py') # convert josnl file to txt file for these extracted features

print('predict Kcr sites using the BiLSTM-based architecture with the extracted features from the pre-trained BERT-Mini model....')
os.system('python2 bert-bilstm.py') # predict Kcr sites using the BiLSTM-based architecture with the extracted features from the pre-trained BERT-Mini model

print('convert predicted file to final readable file....')
os.system('python2 pred2finaltxt.py') # convert predicted file to final readable file
