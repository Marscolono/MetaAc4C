# -*- coding: utf-8 -*-
import numpy as np
import random
random.seed(42)
np.random.seed(1337)  # for reproducibility
import os
import math
from sklearn.metrics import roc_auc_score
import tensorflow as tf
# tf.compat.v1.disable_eager_execution()
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Bidirectional, LSTM, Dropout, Dense, Activation, Flatten
from tensorflow.keras.optimizers import Adam
import sys
tf.set_random_seed(1)





TIME_STEPS = 31
INPUT_SIZE = 256
model = Sequential()
model.add(Bidirectional(LSTM(units=32,
    batch_input_shape=(None,TIME_STEPS, INPUT_SIZE),      
    return_sequences=True,
),merge_mode='concat'))
model.add(Dropout(0.2))
model.add(Flatten())
model.add(Dense(128))
model.add(Activation('relu'))
model.add(Dropout(0.2))
model.add(Dense(2))
model.add(Activation('softmax'))
adam = Adam(2e-4)
model.compile(optimizer=adam,loss='binary_crossentropy',metrics=['accuracy'])



# ----------------------------------------- load features
print('load features……')
sys.stdout.flush()
valid = np.loadtxt('./input/test_features.txt',dtype='str').astype(np.float)
valid = valid.reshape(-1,31,256)

# ------------------------------------------- load model
print('load BERT-Kcr model……')
sys.stdout.flush()
model = tf.keras.models.load_model('../BERT-Kcr-models/BERT_BiLSTM.h5')

# ------------------------------------------- predict
print('start predict……')
sys.stdout.flush()
yy_pred = model.predict_proba(valid, batch_size=16, verbose=1)
np.savetxt('./output/test_bilstm.txt',yy_pred,fmt='%s')

