import os

print('extract features....')
os.system('python2 ./extract-last-layer-features.py')

print('train....')
os.system('python2 train.py')

print('test....')
os.system('python2 ./test.py') 