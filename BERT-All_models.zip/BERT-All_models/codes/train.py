# -*- coding: utf-8 -*-
import numpy as np
import random
random.seed(1)
np.random.seed(17) 
import os
import math
from sklearn.metrics import roc_auc_score
import tensorflow as tf
tf.set_random_seed(153)
from sklearn.preprocessing import OneHotEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Bidirectional, LSTM, Dropout, Dense, Activation, Flatten, Conv1D,MaxPooling1D, GlobalMaxPooling1D
from tensorflow.keras.optimizers import Adam
import sys


#------------------------------------->>> LSTM
# TIME_STEPS = 31
# INPUT_SIZE = 256
# model = Sequential()
# model.add(Bidirectional(LSTM(units=32,
#     batch_input_shape=(None,TIME_STEPS, INPUT_SIZE),       # Or: input_dim=INPUT_SIZE, input_length=TIME_STEPS,
#     return_sequences=True,      # True: output at all steps. False: output as last step.
# ),merge_mode='concat'))
# model.add(Dropout(0.2))
# # add output layer
# model.add(Flatten())
# model.add(Dense(128))
# model.add(Activation('relu'))
# model.add(Dropout(0.2))
# model.add(Dense(2))
# model.add(Activation('softmax'))
# adam =tf.keras.optimizers.Adam(2e-4)
# model.compile(optimizer=adam,loss='binary_crossentropy',metrics=['accuracy'])


#--------------------------------------->> CNN
TIME_STEPS = 27
INPUT_SIZE = 256

def CNN_1D_model():
    model = Sequential()
    model.add(Conv1D(32, 3, batch_input_shape=(None,TIME_STEPS, INPUT_SIZE), activation='relu'))
    model.add(MaxPooling1D(2))
    
    model.add(Conv1D(64, 3, activation='relu'))
    model.add(MaxPooling1D(2))
    
    model.add(Conv1D(128, 3, activation='relu'))
    model.add(MaxPooling1D(2))

    model.add(Dropout(0.2))

    # add output layer
    model.add(Flatten())
    model.add(Dense(128))
    model.add(Activation('relu'))
    model.add(Dropout(0.2))
    model.add(Dense(2))
    model.add(Activation('softmax'))
    adam =tf.keras.optimizers.Adam(2e-4)
    model.compile(optimizer=adam,loss='binary_crossentropy',metrics=['accuracy'])
    return model
    
def CNNLSTM_1D_model():
    model = Sequential()
    model.add(Conv1D(32, 3, batch_input_shape=(None,TIME_STEPS, INPUT_SIZE), activation='relu'))
    model.add(MaxPooling1D(2))
    
    model.add(Conv1D(64, 3, activation='relu'))
    model.add(MaxPooling1D(2))
    
    model.add(Conv1D(128, 3, activation='relu'))
    model.add(MaxPooling1D(2))
    model.add(Bidirectional(LSTM(units=32,batch_input_shape=(None,TIME_STEPS, INPUT_SIZE),return_sequences=True,),merge_mode='concat'))
    
    model.add(Dropout(0.2))
    # add output layer
    model.add(Flatten())
    model.add(Dense(128))
    model.add(Activation('relu'))
    model.add(Dropout(0.2))
    model.add(Dense(2))
    model.add(Activation('softmax'))
    adam =tf.keras.optimizers.Adam(2e-4)
    model.compile(optimizer=adam,loss='binary_crossentropy',metrics=['accuracy'])
    return model

# ----------------------------------------- load labels and features
embedding_path = 'train_and_test_K' #更改数据输入路径

print('load labels……')
sys.stdout.flush()
f1=open('./{}/train.tsv'.format(embedding_path),'r')
data=f1.readlines()
f1.close()
train_label=[]
for ff in range(len(data)):
    train_label.append(int(data[ff].strip().split('\t')[0]))
onehot_encoder = OneHotEncoder(sparse=False)
train_label = np.array(train_label).reshape(len(train_label), 1)
train_label = onehot_encoder.fit_transform(train_label)
print(train_label.shape) #(8616, 2)
print(train_label[:10])

print('load features……')
sys.stdout.flush()
train= np.loadtxt('./{}/train_features.txt'.format(embedding_path)).astype(np.float)
train = train.reshape(-1,27,256) #(8616, 31, 256)
print('train.shape--------------->>>',train.shape)
# train = train.reshape(-1,31,768)
print('train load feature done!',train.shape)
sys.stdout.flush()

# ------------------------------------------- training 
print('start training……')
sys.stdout.flush()
model = CNN_1D_model()

# model.fit(train, train_label, epochs=20, batch_size=16,verbose=1)
# model.save('./train_and_test/BERT_BiLSTM_model.h5')

model.fit(train, train_label, epochs=15, batch_size=16,verbose=1)
model.save('./{}/BERT_CNN_model.h5'.format(embedding_path))
