import os
import numpy as np
np.random.seed(13)
import jsonlines

embedding_path = 'train_and_test_Y'
path = './{}/'.format(embedding_path) # use uniprot base

if os.path.exists(path):
    print('OutputDir is exitsted')
else:
    os.makedirs(path)
    print('success create dir test')
    
#### generate input file for training data
species = 'Y'
f1=open('../IPs_data/{0}/{0}_train_Bert.txt'.format(species),'r')
data1=f1.readlines()
f1.close()

Frag=[]
for i in range(len(data1)):
    if i%2==0:
        label=data1[i].strip().split('|')[0].split(':')[1]
        seq=data1[i+1].strip()
        Frag.append(seq+' '+label)

np.random.shuffle(Frag)
fout1=open(path+'train.tsv','w')
fout2=open(path+'train-nolabel.tsv','w')
for line in Frag:
    label=line.split(' ')[1]
    seq=line.split(' ')[0]
    fout1.write(label+'\t')
    for i in range(len(seq)):
        if i!=(len(seq)-1):
            fout1.write(seq[i]+' ')
            fout2.write(seq[i]+' ')
        else:
            fout1.write(seq[i]+'\n')
            fout2.write(seq[i]+'\n')

fout1.close()
fout2.close()


### extract features for training data
# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./train_and_test/train-nolabel.tsv --output_file=./train_and_test/train.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16')


os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./{0}/train-nolabel.tsv --output_file=./{0}/train.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16'.format(embedding_path))



# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./train_and_test/train-nolabel.tsv --output_file=./train_and_test/train.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16')

# model = 'BERT-Mini'
# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./{0}/train-nolabel.tsv --output_file=./{0}/train.jsonl --vocab_file=../BERT-models/{1}/vocab.txt --bert_config_file=../BERT-models/{1}/config.json --init_checkpoint=../BERT-models/{1}/model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16'.format(embedding_path,model))

layer=[]
with jsonlines.open(path+'train.jsonl') as reader:
    for obj in reader:
        sample=[]
        for j in range(33): #31
            aa=obj['features'][j]['layers'][0]['values']
            sample.extend(aa)
        layer.append(sample)
print('layer.shape:',np.array(layer).shape)
np.savetxt(path+'train_features.txt',layer,fmt='%s')



#### generate input file for test data
f2=open('../IPs_data/{0}/{0}_test_Bert.txt'.format(species),'r')
data2=f2.readlines()
f2.close()

Frag=[]
for i in range(len(data2)):
    if i%2==0:
        label=data2[i].strip().split('|')[0].split(':')[1]
        seq=data2[i+1].strip()
        Frag.append(seq+' '+label)

np.random.shuffle(Frag)
fout1=open(path+'test.tsv','w')
fout2=open(path+'test-nolabel.tsv','w')
for line in Frag:
    label=line.split(' ')[1]
    seq=line.split(' ')[0]
    fout1.write(label+'\t')
    for i in range(len(seq)):
        if i!=(len(seq)-1):
            fout1.write(seq[i]+' ')
            fout2.write(seq[i]+' ')
        else:
            fout1.write(seq[i]+'\n')
            fout2.write(seq[i]+'\n')

fout1.close()
fout2.close()

#### extract features for test data
# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./train_and_test/test-nolabel.tsv --output_file=./train_and_test/test.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16')

os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./{0}/test-nolabel.tsv --output_file=./{0}/test.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16'.format(embedding_path))


# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./train_and_test/test-nolabel.tsv --output_file=./train_and_test/test.jsonl --vocab_file=../BERT-models/BERT-Mini/vocab.txt --bert_config_file=../BERT-models/BERT-Mini/bert_config.json --init_checkpoint=../BERT-models/BERT-Mini/bert_model.ckpt --layers=-1 --max_seq_length=128 --batch_size=16')

# os.system('python2 ./extract_features.py --do_lower_case=True --input_file=./{0}/test-nolabel.tsv --output_file=./{0}/test.jsonl --vocab_file=../BERT-models/{0}/vocab.txt --bert_config_file=../BERT-models/{0}/config.json --init_checkpoint=../BERT-models/{0}/model.ckpt --layers=-1 --max_seq_length=48 --batch_size=16'.format(embedding))

layer=[]
with jsonlines.open(path+'test.jsonl') as reader:
    for obj in reader:
        sample=[]
        for j in range(33): #31
            aa=obj['features'][j]['layers'][0]['values']
            sample.extend(aa)
        layer.append(sample)
print('layer.shape:',np.array(layer).shape)
np.savetxt(path+'test_features.txt',layer,fmt='%s')







