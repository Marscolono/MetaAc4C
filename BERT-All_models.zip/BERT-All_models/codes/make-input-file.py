import sys 

file = sys.argv[1]

f=open(file,'r')
data=f.readlines()
f.close()

fout=open('./input/test-nolabel.tsv','w')
fout1=open('./input/test-mid-pred.txt','w')
fout1.write('sequence	K position\n')
fout2=open('./input/test-mid-nopred.txt','w')
fout2.write('NOTE:\n')
fout2.write("Due to lack information for the front and rear 15nt of a sequence, just give the position of 'K' sites with no prediction:\n")
for i in range(len(data)):
    if i%2==0:
        seqid=data[i].strip()[1:]
        frag=data[i+1].strip()
        K_index=[]
        for i,j in enumerate(frag):
            if j=='K':
                K_index.append(i)
        K_nopred=[]
        K_pred=[]
        for ki in K_index:
            if ki < 15 or (len(frag)-1-ki) < 15:
                K_nopred.append(ki)
            else:
                K_pred.append(ki)
                
        fout2.write('Sequence '+seqid+': ')
        for j in range(len(K_nopred)):
            if j != (len(K_nopred)-1):
                fout2.write(str(K_nopred[j]+1)+',') 
            else:
                fout2.write(str(K_nopred[j]+1)+' ')
        fout2.write('sites.\n')
        
        
        for ki in K_pred:
            fout1.write(seqid+'\t'+str(ki+1)+'\n')
            seq=frag[ki-15:ki+16]
            for k in range(len(seq)):
                if k != (len(seq)-1):
                    fout.write(seq[k]+' ')
                else:
                    fout.write(seq[k]+'\n') 
        
fout.close()
fout1.close()
fout2.close()