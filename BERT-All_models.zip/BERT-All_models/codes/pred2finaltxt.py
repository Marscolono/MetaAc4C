import numpy as np

fout=open('./output/Results.txt','w')
fin1=open('./input/test-mid-pred.txt','r')
data1=fin1.readlines()
fin1.close()
fin2=open('./input/test-mid-nopred.txt','r')
data2=fin2.readlines()
fin2.close()
data3 = np.loadtxt('./output/test_bilstm.txt',dtype=float)


for i in range(len(data1)):
    if i==0:
        fout.write(data1[i].strip()+'\tprediction\n')
    else:
        if data3[i-1][1]>0.5:
            fout.write(data1[i].strip()+'\tKcr site\n')
        else:
            fout.write(data1[i].strip()+'\tnon Kcr site\n')
fout.write('\n\n\n\n')
for line in data2:
    fout.write(line)
fout.close()


