# -*- coding: utf-8 -*-
import numpy as np
import random
# random.seed(42)
# np.random.seed(137) 
import os
import math
from sklearn.metrics import roc_auc_score
import tensorflow as tf
# tf.set_random_seed(141)
from sklearn.preprocessing import OneHotEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Bidirectional, LSTM, Dropout, Dense, Activation, Flatten, Conv1D,MaxPooling1D, GlobalMaxPooling1D
from tensorflow.keras.optimizers import Adam
import sys

from sklearn import metrics
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import roc_curve
from sklearn.metrics import auc
from sklearn.metrics import confusion_matrix,recall_score,matthews_corrcoef,roc_curve,roc_auc_score,auc,precision_recall_curve


def count_data(y, y_hat):
    
    y_true = y  # 真实标签
    pred_y = y_hat
    y_int = np.zeros(shape = y.shape, dtype=np.int32) #将预测小数变成0或者1
    for i in range(len(y)):
        if pred_y[i] < 0.5:
            y_int[i] = 0;
        else:
            y_int[i] = 1;

    acc = metrics.accuracy_score(y_true, y_int)
    prec = metrics.precision_score(y_true, y_int, pos_label=1)  # 精确度
    reca = metrics.recall_score(y_true, y_int, pos_label=1)
    f1 = metrics.f1_score(y_true, y_int)
    mcc = metrics.matthews_corrcoef(y_true, y_int)
    auroc = metrics.roc_auc_score(y_true, y_hat)  # area
    aupr = metrics.average_precision_score(y_true, y_hat)  # area

    # MSE
    MSE = mean_squared_error(y_true, y_hat)
    # MAE
    MAE = mean_absolute_error(y_true, y_hat)

    confusion = confusion_matrix(y, y_int)
    TN, FP, FN, TP = confusion.ravel()

    sensitivity = recall_score(y, y_int)
    specificity = TN / float(TN+FP)

    print('Result: ', '|acc: ', acc,'|prec: ', prec,'|reca: ', reca,'| f1: ', f1,'| mcc: ', mcc,'| auroc: ', auroc,'| aupr: ', aupr,'| MSE: ', MSE,'| MAE: ', MAE,'| Sn: ', sensitivity,'| Sp: ',specificity)
    
    return {'Result: ', '|acc: ', acc,'|prec: ', prec,'|reca: ', reca,'| f1: ', f1,'| mcc: ', mcc,'| auroc: ', auroc,'| aupr: ', aupr,'| MSE: ', MSE,'| MAE: ', MAE,'| Sn: ', sensitivity,'| Sp: ',specificity}


TIME_STEPS = 27
INPUT_SIZE = 256
# INPUT_SIZE = 768

# model = Sequential()
# model.add(Bidirectional(LSTM(units=32,
#     batch_input_shape=(None,TIME_STEPS, INPUT_SIZE),       # Or: input_dim=INPUT_SIZE, input_length=TIME_STEPS,
#     return_sequences=True,      # True: output at all steps. False: output as last step.
# ),merge_mode='concat'))
# model.add(Dropout(0.2))
# # add output layer
# model.add(Flatten())
# model.add(Dense(128))
# model.add(Activation('relu'))
# model.add(Dropout(0.2))
# model.add(Dense(2))
# model.add(Activation('softmax'))
# adam =tf.keras.optimizers.Adam(2e-4)
# model.compile(optimizer=adam,loss='binary_crossentropy',metrics=['accuracy'])

def CNN_1D_model():
    model = Sequential()
    model.add(Conv1D(32, 3, batch_input_shape=(None,TIME_STEPS, INPUT_SIZE), activation='relu'))
    model.add(MaxPooling1D(2))
    
    model.add(Conv1D(64, 3, activation='relu'))
    model.add(MaxPooling1D(2))
    
    model.add(Conv1D(128, 3, activation='relu'))
    model.add(MaxPooling1D(2))
 
    model.add(Dropout(0.2))
    # add output layer
    model.add(Flatten())
    model.add(Dense(128))
    model.add(Activation('relu'))
    model.add(Dropout(0.2))
    model.add(Dense(2))
    model.add(Activation('softmax'))
    adam =tf.keras.optimizers.Adam(2e-4)
    model.compile(optimizer=adam,loss='binary_crossentropy',metrics=['accuracy'])
    return model

# ----------------------------------------- load labels and features
embedding_path = 'train_and_test_K' #更改数据输入路径

print('load labels……')
sys.stdout.flush()
f2=open('./{}/test.tsv'.format(embedding_path),'r')
data=f2.readlines()
f2.close()
test_label=[]
for ff in range(len(data)):
    test_label.append(int(data[ff].strip().split('\t')[0]))
#----------------------->> train
# f1=open('./train_and_test/train.tsv','r')
# data=f1.readlines()
# f1.close()
# train_label=[]
# for ff in range(len(data)):
#     train_label.append(int(data[ff].strip().split('\t')[0]))
#----------------------->> 
print('load features……')
sys.stdout.flush()
test = np.loadtxt('./{}/test_features.txt'.format(embedding_path),dtype='str').astype(np.float)
test = test.reshape(-1,27,256)#
# test = test.reshape(-1,31,768)#

#---------------->>> train
# train = np.loadtxt('./train_and_test/train_features.txt',dtype='str').astype(np.float)
# train = train.reshape(-1,31,256)
# train = train.reshape(-1,31,768)
#---------------->>>

print('test load feature done!',test.shape)
# print('train load feature done!',train.shape)
sys.stdout.flush()

# ------------------------------------------- load model and test
print('load model……')
# model = tf.keras.models.load_model('../BERT-IPs-models/BERT_BiLSTM.h5')
model = CNN_1D_model()
# model = tf.keras.models.load_model('./train_and_test/BERT_BiLSTM_model.h5')
model = tf.keras.models.load_model('./{}/BERT_CNN_model.h5'.format(embedding_path))

print('start predict……')
yy_pred = model.predict_proba(test, batch_size=16, verbose=1)
np.savetxt('./{}/test_realuts.txt'.format(embedding_path),yy_pred,fmt='%s')
true_values = np.array(test_label) ###
y_pred = yy_pred[:,1] #second colums
y_scores = np.array(y_pred)
AUC=roc_auc_score(true_values, y_scores)
result_all = count_data(true_values, y_scores)
print('Test AUC:',AUC)

#------------------------->>> train
# print'count train result ---'
# yy_pred_train = model.predict_proba(train, batch_size=16, verbose=1)
# np.savetxt('./train_and_test/train_realuts.txt',yy_pred_train,fmt='%s')
# true_values_train = np.array(train_label) ###
# y_pred_train = yy_pred_train[:,1] #second colums
# y_scores_train = np.array(y_pred_train)
# AUC_train=roc_auc_score(true_values_train, y_scores_train)
# result_all_train = count_data(true_values_train, y_scores_train)
# print('train AUC:',AUC_train)

# print('All_result:',result_all)
sys.stdout.flush()

# ('Result: ', '|acc: ', 0.819672131147541, '|prec: ', 0.8321167883211679, '|reca: ', 0.8009367681498829, '| f1: ', 0.8162291169451074, '| mcc: ', 0.6397935728452424, '| auroc: ', 0.9045509345575239, '| aupr: ', 0.8952712366309772, '| MSE: ', 0.12540913576279286, '| MAE: ', 0.24375819641295532, '| Sn: ', 0.8009367681498829, '| Sp: ', 0.8384074941451991)

# ST:
# ('Result: ', '|acc: ', 0.7984244670991659, '|prec: ', 0.7701342281879194, '|reca: ', 0.8507877664504171, '| f1: ', 0.808454425363276, '| mcc: ', 0.6001491238994072, '| auroc: ', 0.8890685004221636, '| aupr: ', 0.8899033815100346, '| MSE: ', 0.14735185783929156, '| MAE: ', 0.23053374492711987, '| Sn: ', 0.8507877664504171, '| Sp: ', 0.7460611677479148)

# ('Result: ', '|acc: ', 0.7961075069508804, '|prec: ', 0.7766233766233767, '|reca: ', 0.8313253012048193, '| f1: ', 0.8030438675022381, '| mcc: ', 0.593689543030836, '| auroc: ', 0.888596089641234, '| aupr: ', 0.8876265846857131, '| MSE: ', 0.14560708898746616, '| MAE: ', 0.23487176376157587, '| Sn: ', 0.8313253012048193, '| Sp: ', 0.7608897126969416)

# Y:
# ('Result: ', '|acc: ', 0.7380952380952381, '|prec: ', 0.8125, '|reca: ', 0.6190476190476191, '| f1: ', 0.7027027027027026, '| mcc: ', 0.4902903378454601, '| auroc: ', 0.8798185941043084, '| aupr: ', 0.8686564337342146, '| MSE: ', 0.16932603317365985, '| MAE: ', 0.3189116772264242, '| Sn: ', 0.6190476190476191, '| Sp: ', 0.8571428571428571)
# ('Test AUC:', 0.8798185941043084)


