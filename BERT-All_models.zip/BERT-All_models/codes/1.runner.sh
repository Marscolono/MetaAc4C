


source activate tf1_py2

CUDA_VISIBLE_DEVICES=2 python /BERT-All_models/codes/extract-last-layer-features_All_config.py -species 'ac4c' -max-len 415

