import jsonlines
import numpy as np
import sys


layer=[]
with jsonlines.open('./input/test.jsonl') as reader:
    for obj in reader:
        sample=[]
        for j in range(31):
            aa=obj['features'][j]['layers'][0]['values']
            sample.extend(aa)
        layer.append(sample)
    print('layer.shape:',np.array(layer).shape)
np.savetxt('./input/test_features.txt',layer,fmt='%s')



    
    
    
    
    
    
    
    
    
    
    
    
    
